"""
config.py — all tunables live here, loaded from environment variables
(via a .env file if present). Nothing else in the project should read
os.environ directly; import from here instead so every setting has one
source of truth.
"""
import os
from dotenv import load_dotenv

load_dotenv()  # reads ./.env if it exists; silently does nothing if not


def _get_int(name: str, default: int) -> int:
    val = os.environ.get(name)
    return int(val) if val else default


# --- Groq API ---
GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "")
GROQ_MODEL = os.environ.get("GROQ_MODEL", "llama-3.3-70b-versatile")
MAX_TOKENS = _get_int("GROQ_MAX_TOKENS", 4096)

# --- Harness loop ---
MAX_ITERATIONS = _get_int("MAX_ITERATIONS", 15)
TARGET_REPO_PATH = os.environ.get("TARGET_REPO_PATH", "./target_repo_example")

# --- Sandbox (Docker) ---
SANDBOX_IMAGE = os.environ.get("SANDBOX_IMAGE", "harness-sandbox")
SANDBOX_CPU_LIMIT = os.environ.get("SANDBOX_CPU_LIMIT", "2")
SANDBOX_MEM_LIMIT = os.environ.get("SANDBOX_MEM_LIMIT", "2g")
SANDBOX_TIMEOUT_SEC = _get_int("SANDBOX_TIMEOUT_SEC", 60)
SANDBOX_MAX_OUTPUT_CHARS = _get_int("SANDBOX_MAX_OUTPUT_CHARS", 20_000)

# --- Retry/backoff for Groq's free-tier rate limits ---
# Free-tier TPM/RPM/RPD caps are tight and vary by model/account — see
# https://console.groq.com/docs/rate-limits. We always honor a 429's
# Retry-After header when present, and fall back to exponential backoff
# with jitter when it isn't.
RETRY_MAX_ATTEMPTS = _get_int("RETRY_MAX_ATTEMPTS", 6)
RETRY_BASE_DELAY_SEC = float(os.environ.get("RETRY_BASE_DELAY_SEC", "2.0"))
RETRY_MAX_DELAY_SEC = float(os.environ.get("RETRY_MAX_DELAY_SEC", "60.0"))

# --- Logging ---
RUNS_DIR = os.environ.get("RUNS_DIR", "./runs")


def validate() -> None:
    """Call this at startup so a missing key fails fast with a clear message."""
    if not GROQ_API_KEY:
        raise RuntimeError(
            "GROQ_API_KEY is not set. Copy .env.example to .env and add your "
            "key from https://console.groq.com/keys"
        )
