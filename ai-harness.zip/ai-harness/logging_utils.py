"""
logging_utils.py — structured, per-run logging.

Every harness run gets its own folder under RUNS_DIR:

    runs/20261123-142310-a1b2c3/
        run.log           human-readable, timestamped lines
        transcript.json   full message history + every tool call/result
        result.json       final verdict, written once at the end

Console output stays short (one line per iteration); the full detail
goes to the files so you can debug a run after the fact without
re-running it.
"""
import json
import logging
import os
import time
import uuid
from datetime import datetime, timezone

from config import RUNS_DIR


def new_run_dir() -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    run_dir = os.path.join(RUNS_DIR, f"{stamp}-{uuid.uuid4().hex[:6]}")
    os.makedirs(run_dir, exist_ok=True)
    return run_dir


def get_logger(run_dir: str) -> logging.Logger:
    logger = logging.getLogger(f"harness.{os.path.basename(run_dir)}")
    logger.setLevel(logging.INFO)
    logger.propagate = False

    if logger.handlers:  # avoid duplicate handlers if called twice
        return logger

    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s",
                             datefmt="%H:%M:%S")

    console = logging.StreamHandler()
    console.setFormatter(fmt)
    logger.addHandler(console)

    file_handler = logging.FileHandler(os.path.join(run_dir, "run.log"))
    file_handler.setFormatter(fmt)
    logger.addHandler(file_handler)

    return logger


def save_transcript(run_dir: str, messages: list) -> None:
    """Dumps the full message history (including tool calls/results) as JSON."""
    path = os.path.join(run_dir, "transcript.json")
    with open(path, "w") as f:
        json.dump(messages, f, indent=2, default=str)


def save_result(run_dir: str, result: dict) -> None:
    """Writes the final verdict once, at the end of the run."""
    result = {**result, "logged_at": time.time()}
    path = os.path.join(run_dir, "result.json")
    with open(path, "w") as f:
        json.dump(result, f, indent=2, default=str)
