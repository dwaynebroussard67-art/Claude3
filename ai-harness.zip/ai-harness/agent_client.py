"""
agent_client.py — thin wrapper around the Groq SDK.

Groq's chat-completions API is OpenAI-compatible: tools are described
with {"type": "function", "function": {...}}, and a model turn that
wants to call tools comes back as message.tool_calls (each with an
id, a function name, and JSON-string arguments) rather than Anthropic's
content-block style. main.py is written against *this* wrapper so the
harness loop itself doesn't need to know which provider is underneath.
"""
import json
import random
import time

from groq import Groq
from groq import APIStatusError, APIConnectionError

import config


class RateLimitRetryExhausted(RuntimeError):
    pass


class AgentClient:
    def __init__(self):
        config.validate()
        self._client = Groq(api_key=config.GROQ_API_KEY)

    def create_turn(self, messages: list, tools: list):
        """
        Calls Groq's chat.completions.create with retry/backoff baked in.
        Returns the raw `message` object from choices[0].
        """
        last_err = None
        for attempt in range(1, config.RETRY_MAX_ATTEMPTS + 1):
            try:
                response = self._client.chat.completions.create(
                    model=config.GROQ_MODEL,
                    max_tokens=config.MAX_TOKENS,
                    messages=messages,
                    tools=tools,
                    tool_choice="auto",
                )
                return response.choices[0].message

            except APIStatusError as e:
                last_err = e
                if e.status_code == 429:
                    delay = self._delay_for_429(e, attempt)
                    print(f"[agent_client] rate limited (attempt {attempt}/"
                          f"{config.RETRY_MAX_ATTEMPTS}); waiting {delay:.1f}s")
                    time.sleep(delay)
                    continue
                if e.status_code >= 500:
                    delay = self._backoff_delay(attempt)
                    print(f"[agent_client] Groq server error {e.status_code} "
                          f"(attempt {attempt}); waiting {delay:.1f}s")
                    time.sleep(delay)
                    continue
                raise  # 4xx other than 429 is almost always a bug, not transient

            except APIConnectionError as e:
                last_err = e
                delay = self._backoff_delay(attempt)
                print(f"[agent_client] connection error (attempt {attempt}); "
                      f"waiting {delay:.1f}s")
                time.sleep(delay)

        raise RateLimitRetryExhausted(
            f"Gave up after {config.RETRY_MAX_ATTEMPTS} attempts. Last error: {last_err}"
        )

    # ---------- backoff helpers ----------

    def _delay_for_429(self, err: APIStatusError, attempt: int) -> float:
        """
        Groq sends a `retry-after` header (seconds) on 429s — honor it
        exactly rather than guessing. Fall back to exponential backoff
        with jitter only if the header is missing.
        https://console.groq.com/docs/rate-limits
        """
        headers = getattr(err, "response", None)
        retry_after = None
        if headers is not None:
            raw = headers.headers.get("retry-after")
            if raw is not None:
                try:
                    retry_after = float(raw)
                except ValueError:
                    retry_after = None
        if retry_after is not None:
            return retry_after + random.uniform(0, 0.5)  # small jitter on top
        return self._backoff_delay(attempt)

    def _backoff_delay(self, attempt: int) -> float:
        base = config.RETRY_BASE_DELAY_SEC * (2 ** (attempt - 1))
        capped = min(base, config.RETRY_MAX_DELAY_SEC)
        return capped * random.uniform(0.8, 1.2)  # jitter so retries don't sync up


def parse_tool_calls(message) -> list[dict]:
    """
    Normalizes Groq's tool_calls into plain dicts:
    [{"id": ..., "name": ..., "arguments": {...}}]
    Returns [] if the model didn't call a tool this turn.
    """
    calls = []
    for tc in (message.tool_calls or []):
        try:
            args = json.loads(tc.function.arguments)
        except json.JSONDecodeError:
            args = {}
        calls.append({"id": tc.id, "name": tc.function.name, "arguments": args})
    return calls
