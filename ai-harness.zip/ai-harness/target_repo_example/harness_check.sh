#!/bin/bash
python3 -m pytest test_buggy_calc.py -q
