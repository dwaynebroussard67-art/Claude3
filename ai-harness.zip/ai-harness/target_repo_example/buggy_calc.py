def average(numbers):
    """Returns the average of a list of numbers. Currently buggy."""
    total = 0
    for n in numbers:
        total += n
    return total // len(numbers)  # bug: integer division drops precision
