from buggy_calc import average


def test_average_with_remainder():
    assert average([1, 2, 4]) == 7 / 3


def test_average_whole_numbers():
    assert average([2, 4, 6]) == 4
