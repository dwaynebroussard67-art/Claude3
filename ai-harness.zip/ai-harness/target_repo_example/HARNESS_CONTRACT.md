# Target Repo Contract

The harness (`sandbox_dispatcher.py`) never knows anything
target-specific — it only ever runs two scripts that your target repo
must provide at its root. This is what makes adding a new target
"write two scripts," not "edit the dispatcher."

## Required files

### `harness_build.sh`
- Must be executable (the dispatcher runs `chmod +x` for you, but
  commit it executable anyway: `chmod +x harness_build.sh`).
- Does whatever setup the target needs: install deps, compile, etc.
- **Exit code 0** = build succeeded, proceed to the check.
- **Non-zero** = build failed; the harness stops and shows the model
  your build log instead of running the check.

### `harness_check.sh`
- The win condition. Runs after a successful build.
- **Exit code 0** = done — this is what the agent is working toward.
- **Non-zero** = not done yet; stdout/stderr go back to the model so
  it can see what's still failing.
- Keep this script's own logic simple and deterministic (a test
  runner's exit code is ideal) — the harness trusts it completely.

## Optional

- `requirements.txt` / `package.json` / etc. — whatever your
  `harness_build.sh` wants to install.
- Any other source files the agent will read and edit.

## What the agent can do

- Read any file under the repo root.
- Overwrite any file under the repo root (full file content, not a
  diff — ask it to write the whole new version).
- Trigger `harness_build.sh` then `harness_check.sh` as one step
  (`run_check`).

## What it can't do

- See or touch anything outside the mounted repo directory (path
  traversal is rejected before it reaches the container).
- Reach the network from inside the sandbox (`--network none`).
- Run as root inside the container.

## Example

See the sibling files in this directory (`buggy_calc.py`,
`test_buggy_calc.py`, `harness_build.sh`, `harness_check.sh`) for a
minimal working target: a function with a bug and a failing pytest
test. Point `main.py --target` at this directory to confirm the loop
works end-to-end before pointing it at real code.
