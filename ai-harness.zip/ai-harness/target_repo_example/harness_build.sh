#!/bin/bash
set -e
pip install --quiet --break-system-packages pytest
