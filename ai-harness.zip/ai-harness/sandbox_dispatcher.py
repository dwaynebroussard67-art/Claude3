"""
sandbox_dispatcher.py — the only code that ever touches the Docker
container. Every tool call the model makes is routed through here.

Fixes vs. the earlier draft:
  - Heredoc delimiter is randomized per write (uuid4), not a fixed
    string — a fixed delimiter can collide with content that happens
    to contain it, silently truncating the write.
  - Build/run is templatized: the dispatcher calls the TARGET REPO'S
    OWN `harness_build.sh` / `harness_check.sh` scripts instead of a
    hardcoded compiler invocation. Adding a new target means writing
    those two scripts — never editing this file. See
    target_repo_example/HARNESS_CONTRACT.md for the contract.
  - Removed a dead `quoted_content` variable that was computed but
    never used.
"""
import os
import shlex
import subprocess
import uuid


class SandboxDispatcher:
    """Manages one long-lived Docker container per harness run."""

    TARGET_ROOT = "/workspace/target_repo"

    def __init__(self, target_repo_path: str, image: str,
                 cpu_limit: str, mem_limit: str,
                 timeout_sec: int, max_output_chars: int):
        self.container_name = f"harness-{uuid.uuid4().hex[:8]}"
        self.target_repo_path = os.path.abspath(target_repo_path)
        self.timeout_sec = timeout_sec
        self.max_output_chars = max_output_chars

        cmd = [
            "docker", "run", "-d",
            "--name", self.container_name,
            "--network", "none",                 # no egress, ever
            f"--cpus={cpu_limit}",
            f"--memory={mem_limit}",
            "--pids-limit", "256",                # fork-bomb guard
            # target_repo is read-write: this harness's job is to EDIT
            # code until checks pass, so the model needs to write here.
            # It still never leaves the container (no network) and
            # every path is validated below.
            "-v", f"{self.target_repo_path}:{self.TARGET_ROOT}:rw",
            image,
            "sleep", "infinity",
        ]
        subprocess.run(cmd, check=True, capture_output=True)

    # ---------- internal helpers ----------

    def _exec(self, shell_cmd: str) -> dict:
        full_cmd = ["docker", "exec", self.container_name, "bash", "-c", shell_cmd]
        try:
            result = subprocess.run(
                full_cmd, capture_output=True, text=True, timeout=self.timeout_sec
            )
            stdout = result.stdout[: self.max_output_chars]
            stderr = result.stderr[: self.max_output_chars]
            return {
                "exit_code": result.returncode,
                "stdout": stdout,
                "stderr": stderr,
                "truncated": len(result.stdout) > self.max_output_chars
                or len(result.stderr) > self.max_output_chars,
            }
        except subprocess.TimeoutExpired:
            return {
                "exit_code": -1,
                "stdout": "",
                "stderr": f"[harness] command timed out after {self.timeout_sec}s",
                "truncated": False,
            }

    def _safe_path(self, user_path: str, root: str) -> str | None:
        """Resolves user_path under root; rejects anything that escapes it."""
        candidate = os.path.normpath(os.path.join(root, user_path.lstrip("/")))
        if candidate != root and not candidate.startswith(root + os.sep):
            return None
        return candidate

    # ---------- tool implementations ----------

    def read_file(self, path: str) -> str:
        safe = self._safe_path(path, self.TARGET_ROOT)
        if safe is None:
            return "[error] path traversal rejected"
        result = self._exec(f"head -c {self.max_output_chars} {shlex.quote(safe)} 2>&1")
        if result["exit_code"] != 0:
            return f"[error] could not read file: {result['stderr']}"
        return result["stdout"]

    def write_file(self, path: str, content: str) -> str:
        safe = self._safe_path(path, self.TARGET_ROOT)
        if safe is None:
            return "[error] path traversal rejected"
        delimiter = f"HARNESS_EOF_{uuid.uuid4().hex}"
        cmd = (
            f"mkdir -p $(dirname {shlex.quote(safe)}) && "
            f"cat > {shlex.quote(safe)} << '{delimiter}'\n{content}\n{delimiter}"
        )
        result = self._exec(cmd)
        if result["exit_code"] != 0:
            return f"[error] write failed: {result['stderr']}"
        return f"[ok] wrote {len(content)} bytes to {path}"

    def list_files(self, subdir: str = ".") -> str:
        safe = self._safe_path(subdir, self.TARGET_ROOT)
        if safe is None:
            return "[error] path traversal rejected"
        result = self._exec(f"find {shlex.quote(safe)} -type f -not -path '*/.git/*'")
        return result["stdout"] or "[empty]"

    def run_check(self) -> dict:
        """
        Templatized build/run: calls the target repo's own scripts
        rather than a hardcoded command, so this file never has to
        change when the target changes.
        """
        cmd = (
            f"cd {self.TARGET_ROOT} && "
            "chmod +x harness_build.sh harness_check.sh 2>/dev/null; "
            "./harness_build.sh > /tmp/build.log 2>&1; "
            "build_rc=$?; "
            "if [ $build_rc -ne 0 ]; then "
            "  echo '--- BUILD FAILED ---'; cat /tmp/build.log; exit $build_rc; "
            "fi; "
            "./harness_check.sh"
        )
        return self._exec(cmd)

    # ---------- cleanup ----------

    def shutdown(self) -> None:
        subprocess.run(["docker", "rm", "-f", self.container_name], capture_output=True)
