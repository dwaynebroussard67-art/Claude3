# AI Coding Harness (Groq edition)

A sandboxed loop: a model gets a code repo and a check script, reads
and edits files, and runs the check — repeating until the check
passes or it runs out of attempts. Every edit happens inside an
isolated, network-off Docker container, never on your real machine.

This is the general "agent harness" pattern (model + tools + sandbox +
verification loop), wired to Groq's free API instead of a paid one.

## What each file does

| File | Role |
|---|---|
| `config.py` | every setting, loaded from `.env` |
| `sandbox_dispatcher.py` | the only code that touches Docker |
| `agent_client.py` | Groq API wrapper with retry/backoff for rate limits |
| `main.py` | the loop that ties it all together — run this |
| `logging_utils.py` | writes a full transcript per run under `runs/` |
| `Dockerfile.sandbox` | the sandbox image definition |
| `target_repo_example/` | a tiny working example (see below) |

## Setup, one command at a time

Open a terminal. Paste each block, press Enter, wait for it to finish
before the next one.

**1. Check you have Docker and Python 3.** (If either command errors,
install Docker Desktop from docker.com and Python 3.11+ from
python.org first, then come back here.)

```bash
docker --version
python3 --version
```

**2. Unzip this project and move into it.**

```bash
cd ~/Downloads
unzip ai-harness.zip
cd ai-harness
```

**3. Create a virtual environment** (keeps this project's Python
packages separate from everything else on your machine).

```bash
python3 -m venv venv
source venv/bin/activate
```

You'll know it worked because your terminal prompt now starts with
`(venv)`. You'll need to run that `source` line again every time you
open a new terminal to work on this project.

**4. Install the Python packages this project needs.**

```bash
pip install -r requirements.txt
```

**5. Get a free Groq API key**, then paste it in.

Go to <https://console.groq.com/keys>, sign up (free), create a key,
copy it. Then:

```bash
cp .env.example .env
```

Open the new `.env` file in any text editor and replace
`your-groq-key-here` with the key you copied.

**6. Build the sandbox image** (one-time; rebuild only if you change
`Dockerfile.sandbox`).

```bash
docker build -t harness-sandbox -f Dockerfile.sandbox .
```

**7. Run it against the included example** to confirm everything
works before pointing it at your own code:

```bash
python main.py --target ./target_repo_example
```

You should see iteration logs in the terminal, and after a few
iterations a line saying the check passed. A full transcript lands in
`runs/<timestamp>/`.

## Pointing it at your own code

Any folder that has a `harness_build.sh` and a `harness_check.sh` at
its root works as a target — see
`target_repo_example/HARNESS_CONTRACT.md` for exactly what those two
scripts need to do. Then:

```bash
python main.py --target /path/to/your/repo
```

**Important:** only point this at code you own or are authorized to
test. The agent edits files inside the sandbox copy and runs whatever
`harness_check.sh` tells it to — treat that script as the one thing
standing between "an automated coding assistant" and "something you
didn't mean to run."

## If you hit a Groq rate limit

The free tier's token-per-minute limit is tight. `agent_client.py`
already retries automatically — if you see `[agent_client] rate
limited... waiting Ns`, that's expected; let it finish. If it happens
constantly, lower `MAX_TOKENS` in `.env` or wait a minute between runs.
