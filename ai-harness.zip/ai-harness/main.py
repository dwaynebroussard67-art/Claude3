"""
main.py — the harness loop itself.

Flow: give the model a target repo + a check script, let it read code,
write fixes, and run the check; stop the moment the check exits 0
(the win condition), or when max_iterations runs out.

Usage:
    python main.py                       # uses TARGET_REPO_PATH from config/.env
    python main.py --target ./my_repo    # points at a different target
"""
import argparse
import sys

import config
from agent_client import AgentClient, parse_tool_calls
from sandbox_dispatcher import SandboxDispatcher
from logging_utils import new_run_dir, get_logger, save_transcript, save_result

SYSTEM_PROMPT = """You are an autonomous coding agent working inside a sandboxed \
copy of a code repository.

Your goal: make `./harness_check.sh` exit with code 0. It currently \
does not (that's why you're here).

You have three tools:
- read_file(path): read a file in the repo
- list_files(subdir): see what files exist
- write_file(path, content): overwrite a file with new content (this \
is how you apply a fix — write the FULL new file content, not a diff)

Work iteratively: look at the repo structure, read the relevant \
file(s), understand why the check fails, write a fix, then ask the \
harness to run the check again. Keep going until it passes or you \
run out of attempts. Don't guess blindly — read before you write."""

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read a file from the target repo.",
            "parameters": {
                "type": "object",
                "properties": {"path": {"type": "string"}},
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_files",
            "description": "List files under a directory in the target repo.",
            "parameters": {
                "type": "object",
                "properties": {"subdir": {"type": "string", "description": "defaults to repo root"}},
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Overwrite a file in the target repo with new content.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string"},
                    "content": {"type": "string"},
                },
                "required": ["path", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_check",
            "description": "Build the repo and run harness_check.sh. Returns exit "
                            "code, stdout, stderr. Exit code 0 means you're done.",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
]


def dispatch(sandbox: SandboxDispatcher, name: str, args: dict) -> str:
    try:
        if name == "read_file":
            return sandbox.read_file(args["path"])
        elif name == "list_files":
            return sandbox.list_files(args.get("subdir", "."))
        elif name == "write_file":
            return sandbox.write_file(args["path"], args["content"])
        elif name == "run_check":
            r = sandbox.run_check()
            return (f"exit_code: {r['exit_code']}\n"
                    f"stdout:\n{r['stdout']}\n"
                    f"stderr:\n{r['stderr']}")
        else:
            return f"[error] unknown tool: {name}"
    except Exception as e:  # noqa: BLE001 — a tool bug should never kill the loop
        return f"[error] tool execution failed: {e}"


def run_harness(target_repo_path: str) -> dict:
    run_dir = new_run_dir()
    logger = get_logger(run_dir)
    logger.info(f"Starting run against {target_repo_path}, logs in {run_dir}")

    client = AgentClient()
    sandbox = SandboxDispatcher(
        target_repo_path=target_repo_path,
        image=config.SANDBOX_IMAGE,
        cpu_limit=config.SANDBOX_CPU_LIMIT,
        mem_limit=config.SANDBOX_MEM_LIMIT,
        timeout_sec=config.SANDBOX_TIMEOUT_SEC,
        max_output_chars=config.SANDBOX_MAX_OUTPUT_CHARS,
    )

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": "Begin. Make harness_check.sh pass."},
    ]
    result = {"status": "NO_FINDING", "iterations": config.MAX_ITERATIONS}

    try:
        for i in range(1, config.MAX_ITERATIONS + 1):
            logger.info(f"--- iteration {i}/{config.MAX_ITERATIONS} ---")
            message = client.create_turn(messages, TOOLS)
            messages.append(message.model_dump(exclude_none=True))

            calls = parse_tool_calls(message)
            if not calls:
                logger.info("Model stopped calling tools; ending run.")
                if message.content:
                    logger.info(f"Final message: {message.content}")
                break

            won = False
            for call in calls:
                logger.info(f"tool call: {call['name']}({call['arguments']})")
                output = dispatch(sandbox, call["name"], call["arguments"])
                logger.info(f"tool result ({call['name']}): "
                            f"{output[:300]}{'...' if len(output) > 300 else ''}")
                messages.append({
                    "role": "tool",
                    "tool_call_id": call["id"],
                    "content": output,
                })
                if call["name"] == "run_check" and "exit_code: 0" in output:
                    won = True

            save_transcript(run_dir, messages)

            if won:
                logger.info("Check passed — win condition met.")
                result = {"status": "WIN", "iteration": i}
                break
        else:
            logger.info("Max iterations reached without the check passing.")

    finally:
        sandbox.shutdown()
        save_transcript(run_dir, messages)
        save_result(run_dir, result)

    logger.info(f"Result: {result}")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", default=config.TARGET_REPO_PATH,
                         help="Path to the target repo (must contain "
                              "harness_build.sh + harness_check.sh)")
    args = parser.parse_args()

    try:
        outcome = run_harness(args.target)
    except Exception as e:
        print(f"[fatal] {e}", file=sys.stderr)
        sys.exit(1)

    sys.exit(0 if outcome["status"] == "WIN" else 2)
